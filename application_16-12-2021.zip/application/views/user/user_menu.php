

<section id="content">
    <div class="container">
        <div class="row">

            <div class=" col-md-3">
                <!-- <div class="thumbnail sidebar margintop30 panelmargin5">


                  <ul class="nav nav-sidebar">
                    <li class="active"><a href="<?php echo base_url().'user'; ?>">Basic Details</a></li>
                    <li><a href="<?php echo base_url().'user/addTodayAvailableCars'; ?>">Today Available Cars</a></li>
                    <li><a href="<?php echo base_url().'user/addDroppingCars'; ?>">Dropping Cars</a></li>
                    <li><a href="<?php echo base_url().'user/addSelfDrivingCars'; ?>">Self Driving Cars</a></li>
                    <li><a href="<?php echo base_url().'user/addJobs'; ?>">Jobs</a></li>
                    <li><a href="<?php echo base_url().'user/addTender'; ?>">Tenders</a></li>
                    <li><a href="<?php echo base_url().'user/addVisitingCard'; ?>">Promoting Visiting Cards</a></li>
                    <li><a href="<?php echo base_url().'user/addOthers'; ?>">Others</a></li>
                    <li><a href="<?php echo base_url().'user/addAccident'; ?>">Accident / Breakdown</a></li>
                    <li><a href="<?php echo base_url().'user/addTourpackage'; ?>">Tour Packages</a></li>
                  </ul>

                  helo

                </div> -->
            </div>




