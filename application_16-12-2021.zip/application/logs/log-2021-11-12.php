<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-12 15:00:52 --> Severity: Notice --> Undefined variable: thisCityName C:\xampp\htdocs\cartravels\public_html\application\views\ins\header.php 534
ERROR - 2021-11-12 15:00:52 --> Severity: Notice --> Undefined variable: bgImage C:\xampp\htdocs\cartravels\public_html\application\views\ins\footer.php 205
ERROR - 2021-11-12 15:01:01 --> Severity: Notice --> Undefined variable: bgImage C:\xampp\htdocs\cartravels\public_html\application\views\ins\footer.php 205
ERROR - 2021-11-12 15:02:10 --> Severity: Notice --> Undefined variable: bgImage C:\xampp\htdocs\cartravels\public_html\application\views\ins\footer.php 205
