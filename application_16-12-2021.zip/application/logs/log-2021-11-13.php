<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-13 13:03:38 --> Severity: Notice --> Undefined variable: thisCityName C:\xampp\htdocs\cartravels\public_html\application\views\ins\header.php 534
ERROR - 2021-11-13 13:03:38 --> Severity: Notice --> Undefined variable: bgImage C:\xampp\htdocs\cartravels\public_html\application\views\ins\footer.php 205
ERROR - 2021-11-13 13:04:11 --> Severity: Notice --> Undefined variable: thisCityName C:\xampp\htdocs\cartravels\public_html\application\views\ins\header.php 534
ERROR - 2021-11-13 13:04:11 --> Severity: Notice --> Undefined variable: bgImage C:\xampp\htdocs\cartravels\public_html\application\views\ins\footer.php 205
ERROR - 2021-11-13 13:04:55 --> Severity: Notice --> Undefined variable: bgImage C:\xampp\htdocs\cartravels\public_html\application\views\ins\footer.php 205
