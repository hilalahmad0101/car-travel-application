<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-09 23:23:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\cartravels\public_html\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-11-09 23:23:22 --> Unable to connect to the database
ERROR - 2021-11-09 23:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\cartravels\public_html\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-11-09 23:24:01 --> Unable to connect to the database
ERROR - 2021-11-09 23:24:23 --> Severity: Notice --> Undefined variable: thisCityName C:\xampp\htdocs\cartravels\public_html\application\views\ins\header.php 534
ERROR - 2021-11-09 23:24:24 --> Severity: Notice --> Undefined variable: bgImage C:\xampp\htdocs\cartravels\public_html\application\views\ins\footer.php 205
ERROR - 2021-11-09 23:24:35 --> Severity: Notice --> Undefined variable: bgImage C:\xampp\htdocs\cartravels\public_html\application\views\ins\footer.php 205
ERROR - 2021-11-09 23:49:57 --> Severity: Notice --> Undefined variable: bgImage C:\xampp\htdocs\cartravels\public_html\application\views\ins\footer.php 205
